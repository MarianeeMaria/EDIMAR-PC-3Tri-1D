# pensamentoComputacional-1D
repositorio para compartilhar trabalhos na disciplina de pensamento computacional 
<p> Maria Fernanda e Mariane Loyola. (n:20 e 39)

## -O GATO-

<p> Com um lindo salto
<p> Lesto e seguro
<p> O gato passa
<p> Do chão ao muro
<p> Logo mudando
<p> De opinião
<p> Passa de novo
<p> Do muro ao chão
<p> E pega corre
<p> Bem de mansinho
<p> Atrás de um pobre
<p> De um passarinho
<p> Súbito, para 
<p> Como assombrado
<p> Depois dispara
<p> Pula de lado
<p> E quando tudo
<p> Se lhe fatiga
<p> Toma o seu banho
<p> Passando a língua
<p> Pela barriga.
<p> - Vinicius de Moraes

![Isso é uma imagem](https://catrangers.files.wordpress.com/2013/02/lua-e-artemis.jpg)

@LiziBugalski
